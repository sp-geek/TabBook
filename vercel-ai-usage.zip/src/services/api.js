const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api'

async function request(path, options = {}) {
  const token = localStorage.getItem('tabbook_token')
  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) } })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.message || data.error || 'Request failed')
  return data
}

export const api = {
  auth: { login: (body) => request('/auth/login', { method: 'POST', body: JSON.stringify(body) }), register: (body) => request('/auth/register', { method: 'POST', body: JSON.stringify(body) }) },
  restaurants: { list: () => request('/restaurants'), get: (id) => request(`/restaurants/${id}`) },
  slots: { available: (restaurantId, date) => request(`/slots/available?restaurantId=${restaurantId}&date=${encodeURIComponent(date)}`) },
  bookings: { create: (body) => request('/bookings', { method: 'POST', body: JSON.stringify(body) }), mine: () => request('/bookings/my'), cancel: (id) => request(`/bookings/${id}/cancel`, { method: 'PATCH' }) },
  payments: { createOrder: (body) => request('/payments/create-order', { method: 'POST', body: JSON.stringify(body) }), verify: (body) => request('/payments/verify', { method: 'POST', body: JSON.stringify(body) }) },
}
