const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:5000/api'

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers ?? {}) },
  })
  if (!response.ok) throw new Error(`API request failed: ${response.status}`)
  return response.json()
}

export const api = {
  auth: {
    login: (body: { email: string; password: string }) => request('/auth/login', { method: 'POST', body: JSON.stringify(body) }),
    register: (body: { name: string; email: string; password: string }) => request('/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  },
  restaurants: {
    list: () => request('/restaurants'),
    get: (id: string) => request(`/restaurants/${id}`),
  },
  availability: (restaurantId: string, date: string, guests: number) => request(`/restaurants/${restaurantId}/availability?date=${date}&guests=${guests}`),
  bookings: {
    create: (body: unknown) => request('/bookings', { method: 'POST', body: JSON.stringify(body) }),
    mine: () => request('/bookings/me'),
  },
  payments: {
    createOrder: (body: unknown) => request('/payments/razorpay/order', { method: 'POST', body: JSON.stringify(body) }),
    verify: (body: unknown) => request('/payments/razorpay/verify', { method: 'POST', body: JSON.stringify(body) }),
  },
  admin: {
    overview: () => request('/admin/overview'),
  },
}

export { API_BASE_URL }
