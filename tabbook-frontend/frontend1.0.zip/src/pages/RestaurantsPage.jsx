import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { listRestaurants } from '../api/restaurants';

export default function RestaurantsPage() {
  const [restaurants, setRestaurants] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listRestaurants()
      .then(setRestaurants)
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(
    () =>
      restaurants.filter((r) =>
        `${r.name} ${r.cuisine || ''} ${r.address}`.toLowerCase().includes(search.toLowerCase())
      ),
    [restaurants, search]
  );

  const featured = restaurants[0];

  return (
    <>
      <section className="hero">
        <div>
          <p className="eyebrow">Dining plans, sorted.</p>
          <h1>
            Your next great meal is <em>closer</em> than you think.
          </h1>
          <p className="lede">
            Discover tables worth dressing up for. Pick a time, pick a table on the floor plan, and
            pay in a few taps — no phone calls.
          </p>
          <div className="search">
            <span>&#8981;</span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cuisine, restaurant or area"
            />
          </div>
          <div className="proof">
            <span><span>&#10003;</span>Instant confirmation</span>
            <span><span>&#9689;</span>No phone calls</span>
          </div>
        </div>
        <div className="hero-image">
          <img src="/placeholder.jpg" alt="" />
          <span className="hero-arrow">&#8594;</span>
          {featured && (
            <div>
              <small>TONIGHT&apos;S PICK</small>
              <h2>{featured.name}</h2>
              <p>{featured.cuisine || featured.address}</p>
            </div>
          )}
        </div>
      </section>

      <section className="places">
        <p className="eyebrow">For your table</p>
        <h2>Places taking bookings</h2>

        {loading && <p style={{ color: '#6f7872' }}>Loading…</p>}
        {!loading && filtered.length === 0 && (
          <div className="empty">No restaurants match your search yet.</div>
        )}

        <div className="cards">
          {filtered.map((r) => (
            <Link className="card" to={`/restaurants/${r.id}`} key={r.id}>
              <img src="/placeholder.jpg" alt={r.name} />
              <div className="card-body">
                <h3>{r.name}</h3>
                <p>{r.cuisine || 'Restaurant'}</p>
                <small>
                  &#8982; {r.address} · {r.openTime}–{r.closeTime}
                </small>
                <span className="cta">Find a table →</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
