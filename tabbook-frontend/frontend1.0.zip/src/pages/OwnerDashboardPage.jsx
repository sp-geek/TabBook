import { useEffect, useMemo, useState } from 'react';
import { listRestaurants, createRestaurant } from '../api/restaurants';
import { listTables, createTable, updateTablePosition } from '../api/tables';
import { useAuth } from '../context/AuthContext';
import TableCanvas from '../components/TableCanvas';

const emptyRestaurant = { name: '', address: '', cuisine: '', openTime: '10:00', closeTime: '23:00', slotMinutes: 60 };
const emptyTable = { label: '', capacity: '', area: 'Main Floor' };

export default function OwnerDashboardPage() {
  const { user } = useAuth();
  const [myRestaurants, setMyRestaurants] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [tables, setTables] = useState([]);
  const [selectedArea, setSelectedArea] = useState('Main Floor');
  const [loading, setLoading] = useState(true);

  const [restaurantForm, setRestaurantForm] = useState(emptyRestaurant);
  const [creatingRestaurant, setCreatingRestaurant] = useState(false);

  const [tableForm, setTableForm] = useState(emptyTable);
  const [creatingTable, setCreatingTable] = useState(false);

  function loadRestaurants() {
    setLoading(true);
    listRestaurants()
      .then((all) => {
        const mine = all.filter((r) => r.ownerId === user.id);
        setMyRestaurants(mine);
        if (mine.length > 0) setSelectedId((prev) => prev || mine[0].id);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => { loadRestaurants(); /* eslint-disable-next-line */ }, []);

  function reloadTables() {
    if (!selectedId) return;
    listTables(selectedId).then(setTables);
  }

  useEffect(() => { reloadTables(); /* eslint-disable-next-line */ }, [selectedId]);

  const areas = useMemo(() => {
    const set = new Set(tables.map((t) => t.area || 'Main Floor'));
    set.add(tableForm.area || 'Main Floor');
    return [...set];
  }, [tables, tableForm.area]);

  const tablesInArea = useMemo(
    () => tables.filter((t) => (t.area || 'Main Floor') === selectedArea),
    [tables, selectedArea]
  );

  async function handleCreateRestaurant(e) {
    e.preventDefault();
    setCreatingRestaurant(true);
    try {
      await createRestaurant({ ...restaurantForm, slotMinutes: Number(restaurantForm.slotMinutes) });
      setRestaurantForm(emptyRestaurant);
      loadRestaurants();
    } finally {
      setCreatingRestaurant(false);
    }
  }

  async function handleCreateTable(e) {
    e.preventDefault();
    if (!selectedId) return;
    setCreatingTable(true);
    try {
      const sameArea = tables.filter((t) => (t.area || 'Main Floor') === tableForm.area);
      await createTable(selectedId, {
        label: tableForm.label,
        capacity: Number(tableForm.capacity),
        area: tableForm.area || 'Main Floor',
        posX: 20 + sameArea.length * 90,
        posY: 20,
      });
      setSelectedArea(tableForm.area || 'Main Floor');
      setTableForm({ ...emptyTable, area: tableForm.area });
      reloadTables();
    } finally {
      setCreatingTable(false);
    }
  }

  function handlePositionChange(tableId, { posX, posY }) {
    updateTablePosition(selectedId, tableId, { posX, posY });
  }

  if (loading) return <main className="content"><p style={{ color: '#6f7872' }}>Loading…</p></main>;

  return (
    <main className="content">
      <p className="eyebrow">Restaurant dashboard</p>
      <h1 style={{ fontSize: 44 }}>Good to see you, {user?.name}.</h1>

      {myRestaurants.length > 0 && (
        <div className="restaurant-tabs">
          {myRestaurants.map((r) => (
            <button
              key={r.id}
              className={selectedId === r.id ? 'selected' : ''}
              onClick={() => setSelectedId(r.id)}
            >
              {r.name}
            </button>
          ))}
        </div>
      )}

      {myRestaurants.length === 0 && (
        <div className="panel" style={{ maxWidth: 460, marginBottom: 40 }}>
          <h3>List your restaurant</h3>
          <form onSubmit={handleCreateRestaurant}>
            <input className="field" placeholder="Name" required
              value={restaurantForm.name}
              onChange={(e) => setRestaurantForm({ ...restaurantForm, name: e.target.value })} />
            <input className="field" placeholder="Address" required
              value={restaurantForm.address}
              onChange={(e) => setRestaurantForm({ ...restaurantForm, address: e.target.value })} />
            <input className="field" placeholder="Cuisine (optional)"
              value={restaurantForm.cuisine}
              onChange={(e) => setRestaurantForm({ ...restaurantForm, cuisine: e.target.value })} />
            <div style={{ display: 'flex', gap: 10 }}>
              <input className="field" placeholder="Open (HH:MM)" required
                value={restaurantForm.openTime}
                onChange={(e) => setRestaurantForm({ ...restaurantForm, openTime: e.target.value })} />
              <input className="field" placeholder="Close (HH:MM)" required
                value={restaurantForm.closeTime}
                onChange={(e) => setRestaurantForm({ ...restaurantForm, closeTime: e.target.value })} />
              <input className="field" type="number" placeholder="Slot mins" required
                value={restaurantForm.slotMinutes}
                onChange={(e) => setRestaurantForm({ ...restaurantForm, slotMinutes: e.target.value })} />
            </div>
            <button className="primary" style={{ width: '100%' }} disabled={creatingRestaurant}>
              {creatingRestaurant ? 'Creating…' : 'Create restaurant'}
            </button>
          </form>
        </div>
      )}

      {selectedId && (
        <div className="owner-grid">
          <div className="panel">
            <h3>Add a table</h3>
            <form onSubmit={handleCreateTable}>
              <input className="field" placeholder="Label (e.g. T1)" required
                value={tableForm.label}
                onChange={(e) => setTableForm({ ...tableForm, label: e.target.value })} />
              <input className="field" type="number" placeholder="Capacity" required
                value={tableForm.capacity}
                onChange={(e) => setTableForm({ ...tableForm, capacity: e.target.value })} />
              <input className="field" placeholder="Area (e.g. Main Floor, Open Roof)"
                value={tableForm.area}
                onChange={(e) => setTableForm({ ...tableForm, area: e.target.value })} />
              <button className="primary" style={{ width: '100%' }} disabled={creatingTable}>
                {creatingTable ? 'Adding…' : 'Add table'}
              </button>
            </form>
            <p className="hint">
              Drag tables on the floor plan to arrange them — positions save automatically. Give
              tables a different "Area" name (like "Open Roof") to create a new floor.
            </p>
          </div>

          <div>
            {areas.length > 1 && (
              <div className="tabs" style={{ marginBottom: 12 }}>
                {areas.map((a) => (
                  <button key={a} className={selectedArea === a ? 'selected' : ''} onClick={() => setSelectedArea(a)}>
                    {a}
                  </button>
                ))}
              </div>
            )}
            <h3 style={{ fontFamily: "'Space Grotesk'", marginTop: 0 }}>{selectedArea} — floor plan</h3>
            <TableCanvas tables={tablesInArea} mode="edit" onPositionChange={handlePositionChange} />
          </div>
        </div>
      )}
    </main>
  );
}
