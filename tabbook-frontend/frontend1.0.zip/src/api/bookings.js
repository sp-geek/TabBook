import client from './client';

// Requires tableId + slotStart/slotEnd — NOT date+time+guests like the v0 scaffold assumed.
// Your backend books a specific table for a specific slot, not a generic party size.
export function createBooking({ tableId, date, slotStart, slotEnd }) {
  return client.post('/api/bookings', { tableId, date, slotStart, slotEnd }).then((r) => r.data);
}

export function listMyBookings() {
  return client.get('/api/bookings/mine').then((r) => r.data);
}

export function cancelBooking(id) {
  return client.patch(`/api/bookings/${id}/cancel`).then((r) => r.data);
}
