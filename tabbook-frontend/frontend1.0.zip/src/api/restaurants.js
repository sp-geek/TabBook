import client from './client';

export function listRestaurants() {
  return client.get('/api/restaurants').then((r) => r.data);
}

export function getRestaurant(id) {
  return client.get(`/api/restaurants/${id}`).then((r) => r.data);
}

export function createRestaurant(data) {
  return client.post('/api/restaurants', data).then((r) => r.data);
}
